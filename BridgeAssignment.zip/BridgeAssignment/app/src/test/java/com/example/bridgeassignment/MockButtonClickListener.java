package com.example.bridgeassignment;

import android.view.View;

import org.junit.Ignore;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;


public class MockButtonClickListener {
    @Ignore
    public static Answer invokeListener(final View btn) {
        return new Answer() {
            @Override
            public Object answer(InvocationOnMock iom) throws Throwable {
                ((View.OnClickListener) iom.getArguments()[0]).onClick(btn);
                return null;
            }
        };
    }

}

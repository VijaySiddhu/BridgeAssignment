package com.example.bridgeassignment;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.core.content.ContextCompat;

import com.example.bridgeassignment.model.Pupil;
import com.example.bridgeassignment.service.GetDataService;
import com.example.bridgeassignment.utility.NetworkConnection;
import com.example.bridgeassignment.views.AddPupilActivity;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.spy;

@PowerMockIgnore({"javax.crypto.*"})
@RunWith(PowerMockRunner.class)
@PrepareForTest({ContextCompat.class, NetworkConnection.class, String.class})
public class AddPupilActivityUnitTest {

    @Mock
    private View view;
    @Mock
    private Button addPupilButton;
    @Mock
    Pupil pupil;
    @Mock
    private EditText pupilName, pupilImage, pupilCountry, pupilLatitude, pupilLongitude;

    private AddPupilActivity addPupilActivity;

    @Before
    public void setUp() {
        mockStatic(View.class);
        mockStatic(NetworkConnection.class);
        List<Pupil> pupilList = new ArrayList<>();
        pupil = new Pupil();
        pupil.setPupil_id(111L);
        pupil.setName("James");
        pupil.setCountry("US");
        pupil.setImage("userImage");
        pupil.setLatitude(12.304);
        pupil.setLongitude(56.30214);
        pupilList.add(pupil);
        when(view.findViewById(R.id.pupil_name_et)).thenReturn(pupilName);
        when(view.findViewById(R.id.pupil_name_et)).thenReturn(pupilName);
        when(view.findViewById(R.id.pupil_image_et)).thenReturn(pupilImage);
        when(view.findViewById(R.id.pupil_country_et)).thenReturn(pupilCountry);
        when(view.findViewById(R.id.pupil_latitude_et)).thenReturn(pupilLatitude);
        when(view.findViewById(R.id.pupil_longitude_et)).thenReturn(pupilLongitude);
        when(view.findViewById(R.id.button_add_pupil)).thenReturn(addPupilButton);

        addPupilActivity = spy(new AddPupilActivity());
        addPupilActivity.setTestParams(addPupilActivity);
    }

    @Test
    public void send_post_test() {
        PowerMockito.when(NetworkConnection.isConnectingToInternet(addPupilActivity)).thenReturn(true);
        verify(addPupilActivity, times(1)).sendPost(any(GetDataService.class), any(String.class), any(String.class),
                any(String.class), any(Double.class), any(Double.class));
    }

    @Test
    public void send_post_noNetwork_connection_test() {
        PowerMockito.when(NetworkConnection.isConnectingToInternet(addPupilActivity)).thenReturn(false);
        verify(addPupilActivity, times(0)).sendPost(any(GetDataService.class), any(String.class), any(String.class),
                any(String.class), any(Double.class), any(Double.class));
    }
}

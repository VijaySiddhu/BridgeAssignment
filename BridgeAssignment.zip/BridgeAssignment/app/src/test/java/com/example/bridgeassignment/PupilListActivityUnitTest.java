package com.example.bridgeassignment;

import android.view.View;
import android.widget.Button;

import androidx.core.content.ContextCompat;

import com.example.bridgeassignment.model.Pupil;
import com.example.bridgeassignment.utility.NetworkConnection;
import com.example.bridgeassignment.views.PupilListActivity;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.bridgeassignment.MockButtonClickListener.invokeListener;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

@PowerMockIgnore({"javax.crypto.*"})
@RunWith(PowerMockRunner.class)
@PrepareForTest({ContextCompat.class, NetworkConnection.class, String.class})

public class PupilListActivityUnitTest {

    private PupilListActivity pupilListActivity;

    @Mock
    Response response;
    @Mock
    Call call;
    @Mock
    private Button addPupilButton;
    @Mock
    private View view;
    @Mock
    Pupil pupil;

    @Before
    public void setUp() {
        mockStatic(View.class);
        List<Pupil> pupilList = new ArrayList<>();
        pupil = new Pupil();
        pupil.setPupil_id(111L);
        pupil.setName("James");
        pupil.setCountry("US");
        pupil.setImage("userImage");
        pupil.setLatitude(12.304);
        pupil.setLongitude(56.30214);
        pupilList.add(pupil);

        mockStatic(NetworkConnection.class);
        pupilListActivity = spy(new PupilListActivity());
        pupilListActivity.setTestParams(pupilListActivity);
        when(view.findViewById(R.id.add_pupil)).thenReturn(addPupilButton);


    }

    @Test
    public void get_pupilList_test_onResponse() {
        doAnswer(new Answer<InvocationOnMock>() {
            @Override
            public InvocationOnMock answer(InvocationOnMock iom) {
                ((Callback) iom.getArguments()[0]).onResponse(call, response);
                return null;
            }
        }).when(pupilListActivity).getPupilList();
        verify(pupilListActivity, times(1)).getPupilList();
    }

    @Test
    public void get_pupilList_test_onFailure() {
        doAnswer(new Answer<InvocationOnMock>() {
            @Override
            public InvocationOnMock answer(InvocationOnMock iom) {
                ((Callback) iom.getArguments()[0]).onFailure(call, any(Throwable.class));
                return null;
            }
        }).when(pupilListActivity).getPupilList();
    }

    @Test
    public void get_pupilList_test_noNetwork_connection() {
        doAnswer(new Answer<InvocationOnMock>() {
            @Override
            public InvocationOnMock answer(InvocationOnMock iom) {
                ((Callback) iom.getArguments()[0]).onResponse(call, response);
                return null;
            }
        }).when(pupilListActivity).getPupilList();
        when(NetworkConnection.isConnectingToInternet(pupilListActivity)).thenReturn(false);
        verify(pupilListActivity, times(0)).getPupilList();
    }

    public void get_pupilList_test_network_connection() {
        doAnswer(new Answer<InvocationOnMock>() {
            @Override
            public InvocationOnMock answer(InvocationOnMock iom) {
                ((Callback) iom.getArguments()[0]).onResponse(call, response);
                return null;
            }
        }).when(pupilListActivity).getPupilList();
        when(NetworkConnection.isConnectingToInternet(pupilListActivity)).thenReturn(true);
        verify(pupilListActivity, times(1)).getPupilList();
    }

    @Test
    public void add_pupil_button_click_test() {
        when(view.findViewById(R.id.add_pupil)).thenReturn(addPupilButton);
        doAnswer(invokeListener(addPupilButton)).when(addPupilButton).setOnClickListener(any(View.OnClickListener.class));
        verify(pupilListActivity, times(1)).addNewPeople();
    }

}

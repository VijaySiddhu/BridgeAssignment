package com.example.bridgeassignment.service;

import com.example.bridgeassignment.model.Pupil;
import com.example.bridgeassignment.model.PupilsList;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;

public interface GetDataService {
    @Headers({
            "X-Request-ID: dda7feeb-20af-415e-887e-afc43f245624",
            "User-Agent: Bridge Android Tech Test"
    })
    @GET("pupils")
    Call<PupilsList> getAllPupil(
            @QueryMap Map<String, String> options
    );

    @Headers({
            "X-Request-ID: dda7feeb-20af-415e-887e-afc43f245624",
            "User-Agent: Bridge Android Tech Test"
    })
    @POST("/pupils")
    Call<Pupil> postPupil(@Body Pupil pupil);


}

package com.example.bridgeassignment.views;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bridgeassignment.R;
import com.example.bridgeassignment.adapter.CustomAdapter;
import com.example.bridgeassignment.database.DatabaseAdapter;
import com.example.bridgeassignment.model.Pupil;
import com.example.bridgeassignment.model.PupilsList;
import com.example.bridgeassignment.retrofit.RetrofitClientInstance;
import com.example.bridgeassignment.service.GetDataService;
import com.example.bridgeassignment.utility.NetworkChangeReceiver;
import com.example.bridgeassignment.utility.NetworkConnection;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private ProgressDialog progressDialog;
    private DatabaseAdapter databaseAdapter;
    private TextView textView;
    private BroadcastReceiver broadcastReceiver;
    public static boolean isPupilDataFetched = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        initViews();
        /*Create handle for the RetrofitInstance interface*/
        if (NetworkConnection.isConnectingToInternet(MainActivity.this)) {
            getPupilList();
        } else {
            populateDataList(databaseAdapter.getPupilList());
        }

    }

    /**
     * Populating the views
     */
    private void initViews() {
        databaseAdapter = new DatabaseAdapter(MainActivity.this);
        broadcastReceiver = new NetworkChangeReceiver();
        Button addPupilButton = findViewById(R.id.add_pupil);
        textView = findViewById(R.id.no_pupil_to_display);
        registerNetworkBroadcastForNougat();
        addPupilButton.setOnClickListener(this);
    }

    public void getPupilList() {
        isPupilDataFetched = true;
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage(getResources().getString(R.string.fetching_pupil_list));
        progressDialog.setCancelable(false);
        progressDialog.show();
        Map<String, String> data = new HashMap<>();
        data.put("page", String.valueOf(1));
        GetDataService service = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        Call<PupilsList> call = service.getAllPupil(data);
        call.enqueue(new Callback<PupilsList>() {
            @Override
            public void onResponse(@NonNull Call<PupilsList> call, @NonNull Response<PupilsList> response) {
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
                if (response.body() != null) {
                    databaseAdapter.insertPupilList(response.body().getItems());
                    populateDataList(response.body().getItems());
                }
            }

            @Override
            public void onFailure(@NonNull Call<PupilsList> call, @NonNull Throwable t) {
                Toast.makeText(MainActivity.this, getResources().getString(R.string.error_msg_while_fetching_list), Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Populating the users list to UI using Recycler view and adapter
     *
     * @param pupilList List<Pupil>
     */
    private void populateDataList(List<Pupil> pupilList) {
        if (pupilList.isEmpty()) {
            textView.setVisibility(View.VISIBLE);
        } else {
            textView.setVisibility(View.INVISIBLE);
            RecyclerView recyclerView = findViewById(R.id.pupil_recycler_view);
            CustomAdapter adapter = new CustomAdapter(this, pupilList);
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);
            recyclerView.setLayoutManager(layoutManager);
            recyclerView.setAdapter(adapter);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.add_pupil:
                addNewPeople();

        }
    }

    /**
     * Navigating the user to AddPupil screen on clicking the Add Pupil button
     */
    private void addNewPeople() {
        Intent intent = new Intent(MainActivity.this, AddPupilActivity.class);
        startActivity(intent);
    }

    /**
     * Registering the Broadcast receiver for Network change detection
     */
    private void registerNetworkBroadcastForNougat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }
    }
}



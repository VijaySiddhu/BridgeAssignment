package com.example.bridgeassignment.utility;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.example.bridgeassignment.R;
import com.example.bridgeassignment.views.PupilListActivity;

public class NetworkChangeReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(final Context context, final Intent intent) {
        PupilListActivity pupilListActivity = (PupilListActivity)context;
        if (NetworkConnection.isConnectingToInternet(context)) {
            Toast.makeText(context, context.getResources().getString(R.string.connected_to_internet), Toast.LENGTH_SHORT).show();
            if(context.getClass().getName().contains("PupilListActivity") && !PupilListActivity.isPupilDataFetched) {
                pupilListActivity.getPupilList();

            }
        } else {
            PupilListActivity.isPupilDataFetched = false;
            Toast.makeText(context, context.getResources().getString(R.string.no_connection), Toast.LENGTH_LONG).show();
        }
    }
}
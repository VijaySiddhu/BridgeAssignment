package com.example.bridgeassignment.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.example.bridgeassignment.model.Pupil;

import java.util.ArrayList;
import java.util.List;

public class DatabaseAdapter {

    private Context context;
    private SQLiteDatabase database;

    public DatabaseAdapter(Context context) {
        this.context = context;
    }

    private void open() throws SQLException {

        DatabaseHelper dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
    }

    private SQLiteDatabase getDatabase() {
        if (database == null || !database.isOpen())
            open();
        return database;
    }

    /**
     * Pupil Table columns
     */
    static final String DATABASE_TABLE_PUPIL = "Pupil";
    static final String COLUMN_PUPIL_ID = "Pupilid";
    static final String COLUMN_PUPIL_COUNTRY = "pupilCountry";
    static final String COLUMN_PUPIL_NAME = "PupilName";
    static final String COLUMN_PUPIL_IMAGE = "PupilImage";
    static final String COLUMN_PUPIL_LATITUDE = "Latitude";
    static final String COLUMN_PUPIL_LONGITUDE = "Longitude";

    /**
     * Insert Pupil List
     *
     * @param pupilList List<Pupil>
     */
    public void insertPupilList(List<Pupil> pupilList) {
        int size = pupilList.size();
        for (int i = 0; i < size; i++) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_PUPIL_ID, pupilList.get(i).getPupilid());
            values.put(COLUMN_PUPIL_COUNTRY, pupilList.get(i).getCountry());
            values.put(COLUMN_PUPIL_NAME, pupilList.get(i).getName());
            values.put(COLUMN_PUPIL_IMAGE, pupilList.get(i).getImage());
            values.put(COLUMN_PUPIL_LATITUDE, pupilList.get(i).getLatitude());
            values.put(COLUMN_PUPIL_LONGITUDE, pupilList.get(i).getLongitude());
            getDatabase().insert(DATABASE_TABLE_PUPIL, null, values);
        }
    }

    /**
     * Insert Pupil
     *
     * @param pupil Pupil
     */
    public void insertPupil(Pupil pupil) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_PUPIL_ID, pupil.getPupilid());
        values.put(COLUMN_PUPIL_COUNTRY, pupil.getCountry());
        values.put(COLUMN_PUPIL_NAME, pupil.getName());
        values.put(COLUMN_PUPIL_IMAGE, pupil.getImage());
        values.put(COLUMN_PUPIL_LATITUDE, pupil.getLatitude());
        values.put(COLUMN_PUPIL_LONGITUDE, pupil.getLongitude());
         getDatabase().insert(DATABASE_TABLE_PUPIL, null, values);
    }


    /**
     * Gets Pupil List
     *
     * @return pupilList
     */
    public List<Pupil> getPupilList() {
        List<Pupil> pupilList = new ArrayList<>();

        String[] projection = new String[]{COLUMN_PUPIL_ID, COLUMN_PUPIL_NAME, COLUMN_PUPIL_COUNTRY, COLUMN_PUPIL_IMAGE
                , COLUMN_PUPIL_LATITUDE, COLUMN_PUPIL_LONGITUDE};

        Cursor cursor = getDatabase().query(DATABASE_TABLE_PUPIL, projection, null, null, null, null, null);
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    Pupil pupil = new Pupil();
                    pupil.setPupil_id(cursor.getLong(0));
                    pupil.setName(cursor.getString(1));
                    pupil.setCountry(cursor.getString(2));
                    pupil.setImage(cursor.getString(3));
                    pupil.setLatitude(cursor.getDouble(4));
                    pupil.setLongitude(cursor.getDouble(5));
                    pupilList.add(pupil);
                }
            }
            cursor.close();
        }
        return pupilList;
    }
}

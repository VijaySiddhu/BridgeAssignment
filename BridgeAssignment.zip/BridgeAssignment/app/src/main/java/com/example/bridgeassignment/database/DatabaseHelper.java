package com.example.bridgeassignment.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper  extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Bridge";
    private static final int DATABASE_VERSION = 1;

    DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(DATABASE_CREATE_TABLE_PUPIL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }


    private static final String DATABASE_CREATE_TABLE_PUPIL = "create table if not exists "
            + DatabaseAdapter.DATABASE_TABLE_PUPIL
            + " ("
            + DatabaseAdapter.COLUMN_PUPIL_ID +" INTEGER  , "
            + DatabaseAdapter.COLUMN_PUPIL_NAME +" TEXT  , "
            + DatabaseAdapter.COLUMN_PUPIL_COUNTRY +" TEXT  , "
            + DatabaseAdapter.COLUMN_PUPIL_IMAGE + " TEXT , "
            + DatabaseAdapter.COLUMN_PUPIL_LATITUDE + " REAL , "
            + DatabaseAdapter.COLUMN_PUPIL_LONGITUDE + " REAL);";

}

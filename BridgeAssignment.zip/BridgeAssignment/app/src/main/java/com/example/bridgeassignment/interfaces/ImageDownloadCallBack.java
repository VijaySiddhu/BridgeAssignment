package com.example.bridgeassignment.interfaces;

public interface ImageDownloadCallBack {

        void onDownloadImageCompleted(String image);

        void onDownloadImageFailed();

}

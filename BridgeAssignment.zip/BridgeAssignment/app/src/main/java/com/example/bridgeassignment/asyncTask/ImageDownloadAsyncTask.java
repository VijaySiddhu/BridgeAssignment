package com.example.bridgeassignment.asyncTask;

import android.os.AsyncTask;

import com.example.bridgeassignment.interfaces.ImageDownloadCallBack;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ImageDownloadAsyncTask extends AsyncTask<Void, Void, String> {
    private static final String REQUEST_METHOD = "GET";
    private static final int READ_TIMEOUT = 300000;
    private static final int CONNECTION_TIMEOUT = 300000;
    private URL imageUrl;
    private ImageDownloadCallBack imageDownloadCallback;

    public ImageDownloadAsyncTask(URL imageUrl, ImageDownloadCallBack mImageDownloadCallBack) {
        this.imageUrl = imageUrl;
        this.imageDownloadCallback = mImageDownloadCallBack;
    }

    @Override
    protected String doInBackground(Void... voids) {
        String result;
        String inputLine;
        try {
            HttpURLConnection connection = (HttpURLConnection)
                    imageUrl.openConnection();
            connection.setRequestMethod(REQUEST_METHOD);
            connection.setReadTimeout(READ_TIMEOUT);
            connection.setConnectTimeout(CONNECTION_TIMEOUT);

            connection.connect();
            InputStreamReader streamReader = new
                    InputStreamReader(connection.getInputStream());
            BufferedReader reader = new BufferedReader(streamReader);
            StringBuilder stringBuilder = new StringBuilder();
            while ((inputLine = reader.readLine()) != null) {
                stringBuilder.append(inputLine);
            }
            reader.close();
            streamReader.close();
            result = stringBuilder.toString();
        } catch (IOException e) {
            e.printStackTrace();
            result = null;
        }
        return result;
    }

    protected void onPostExecute(String result) {
        super.onPostExecute(result);
        if (result != null) {
            imageDownloadCallback.onDownloadImageCompleted(result);
        }else
            imageDownloadCallback.onDownloadImageFailed();
    }
}

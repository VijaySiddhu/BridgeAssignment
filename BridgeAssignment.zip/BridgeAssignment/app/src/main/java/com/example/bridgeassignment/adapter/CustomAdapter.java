package com.example.bridgeassignment.adapter;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bridgeassignment.R;
import com.example.bridgeassignment.model.Pupil;
import com.example.bridgeassignment.utility.NetworkConnection;

import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder> {

    private List<Pupil> dataList;
    private Context context;
    private ProgressDialog progressDialog;

    public CustomAdapter(Context context, List<Pupil> dataList) {
        this.context = context;
        this.dataList = dataList;
    }


    class CustomViewHolder extends RecyclerView.ViewHolder {

        final View mView;

        private TextView pupilId;
        private TextView pupilCountry;
        private TextView pupilName;
        private TextView pupilLatitude;
        private TextView pupilLongitude;
        private ImageView pupilImage;

        CustomViewHolder(View itemView) {
            super(itemView);
            mView = itemView;

            pupilId = mView.findViewById(R.id.pupil_id_value);
            pupilCountry = mView.findViewById(R.id.pupil_country_value);
            pupilName = mView.findViewById(R.id.pupil_name_value);
            pupilLatitude = mView.findViewById(R.id.pupil_latitude_value);
            pupilLongitude = mView.findViewById(R.id.pupil_longitude_value);
            pupilImage = mView.findViewById(R.id.pupil_image);
        }
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.list_item, parent, false);
        return new CustomViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final CustomViewHolder holder, int position) {
        holder.pupilId.setText(Long.toString(dataList.get(position).getPupilid()));
        holder.pupilName.setText(dataList.get(position).getName());
        holder.pupilCountry.setText(dataList.get(position).getCountry());
        holder.pupilLatitude.setText(Double.toString(dataList.get(position).getLatitude()));
        holder.pupilLongitude.setText(Double.toString(dataList.get(position).getLongitude()));
        if (NetworkConnection.isConnectingToInternet(context)) {
            if (position == 0) {
                progressDialog = new ProgressDialog(context);
                progressDialog.setMessage(context.getResources().getString(R.string.fetching_image_message));
                progressDialog.setCancelable(false);
                progressDialog.show();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Drawable drw = null;
                        try {
                            drw = DownloadDrawable(dataList.get(0).getImage(), "src");
                            holder.pupilImage.setImageDrawable(drw);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        finally {
                            if (progressDialog.isShowing())
                                progressDialog.dismiss();
                        }

                    }
                }).start();

            }

        } else {
            Toast.makeText(context, context.getResources().getString(R.string.no_connection), Toast.LENGTH_SHORT).show();
        }

    }

    private Drawable DownloadDrawable(String url, String src_name) throws java.io.IOException {
        return Drawable.createFromStream(((java.io.InputStream) new java.net.URL(url).getContent()), src_name);
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }
}


package com.example.bridgeassignment.adapter;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bridgeassignment.asyncTask.ImageDownloadAsyncTask;
import com.example.bridgeassignment.interfaces.ImageDownloadCallBack;
import com.example.bridgeassignment.R;
import com.example.bridgeassignment.model.Pupil;
import com.example.bridgeassignment.utility.NetworkConnection;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder> {

    private List<Pupil> dataList;
    private Context context;
    private ProgressDialog progressDialog;

    public CustomAdapter(Context context, List<Pupil> dataList) {
        this.context = context;
        this.dataList = dataList;
    }


    class CustomViewHolder extends RecyclerView.ViewHolder {

        final View mView;

        private TextView pupilId;
        private TextView pupilCountry;
        private TextView pupilName;
        private TextView pupilLatitude;
        private TextView pupilLongitude;
        private ImageView pupilImage;

        CustomViewHolder(View itemView) {
            super(itemView);
            mView = itemView;

            pupilId = mView.findViewById(R.id.pupil_id_value);
            pupilCountry = mView.findViewById(R.id.pupil_country_value);
            pupilName = mView.findViewById(R.id.pupil_name_value);
            pupilLatitude = mView.findViewById(R.id.pupil_latitude_value);
            pupilLongitude = mView.findViewById(R.id.pupil_longitude_value);
            pupilImage = mView.findViewById(R.id.pupil_image);
        }
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.list_item, parent, false);
        return new CustomViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final CustomViewHolder holder, int position) {
        holder.pupilId.setText(Long.toString(dataList.get(position).getPupilid()));
        holder.pupilName.setText(dataList.get(position).getName());
        holder.pupilCountry.setText(dataList.get(position).getCountry());
        holder.pupilLatitude.setText(Double.toString(dataList.get(position).getLatitude()));
        holder.pupilLongitude.setText(Double.toString(dataList.get(position).getLongitude()));
        if (NetworkConnection.isConnectingToInternet(context)) {
            if (position == 0) {
                try {
                    progressDialog = new ProgressDialog(context);
                    progressDialog.setMessage(context.getResources().getString(R.string.fetching_image_message));
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                    new ImageDownloadAsyncTask(new URL(dataList.get(position).getImage()), new ImageDownloadCallBack() {
                        @Override
                        public void onDownloadImageCompleted(String image) {
                            if (progressDialog.isShowing())
                                progressDialog.dismiss();
//                            byte[] encodeByte = Base64.decode(image, Base64.DEFAULT);
//                            Bitmap bitmap = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
//                            holder.pupilImage.setImageBitmap(bitmap);

                        }

                        @Override
                        public void onDownloadImageFailed() {
                            if (progressDialog.isShowing())
                                progressDialog.dismiss();
                            Toast.makeText(context, context.getResources().getString(R.string.error_msg_white_fetching_image), Toast.LENGTH_SHORT).show();

                        }
                    }).execute();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            Toast.makeText(context, context.getResources().getString(R.string.no_connection), Toast.LENGTH_SHORT).show();
        }

    }


    @Override
    public int getItemCount() {
        return dataList.size();
    }
}


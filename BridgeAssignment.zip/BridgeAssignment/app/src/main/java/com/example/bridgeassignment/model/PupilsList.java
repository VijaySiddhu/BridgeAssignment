package com.example.bridgeassignment.model;

import java.util.List;

public class PupilsList {
    private List<Pupil> items;

    public List<Pupil> getItems() {
        return items;
    }

    public void setItems(List<Pupil> items) {
        this.items = items;
    }
}

package com.example.bridgeassignment.views;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.bridgeassignment.R;
import com.example.bridgeassignment.database.DatabaseAdapter;
import com.example.bridgeassignment.model.Pupil;
import com.example.bridgeassignment.retrofit.RetrofitClientInstance;
import com.example.bridgeassignment.service.GetDataService;
import com.example.bridgeassignment.utility.NetworkConnection;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddPupilActivity extends AppCompatActivity {
    private EditText pupilImageEditText;
    private EditText pupilNameEditText;
    private EditText pupilLatitudeEditText;
    private EditText pupilLongitudeEditText;
    private EditText pupilCountryEditText;
    private ProgressDialog progressDialog;
    private DatabaseAdapter databaseAdapter;
    private Pupil pupil;
    private Context context ;

    public void setTestParams(AddPupilActivity addPupilActivity) {
        this.context = addPupilActivity;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setContentView(R.layout.add_pupil_activity);
        initViews();
    }

    private void initViews() {
        pupilImageEditText = findViewById(R.id.pupil_image_et);
        pupilCountryEditText = findViewById(R.id.pupil_country_et);
        pupilNameEditText = findViewById(R.id.pupil_name_et);
        pupilLatitudeEditText = findViewById(R.id.pupil_latitude_et);
        pupilLongitudeEditText = findViewById(R.id.pupil_longitude_et);
        Button addPupilButton = findViewById(R.id.button_add_pupil);
        databaseAdapter = new DatabaseAdapter(AddPupilActivity.this);
        pupil = new Pupil();
        addPupilButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (pupilImageEditText.getText().toString().isEmpty() ||
                        pupilCountryEditText.getText().toString().isEmpty() ||
                        pupilNameEditText.getText().toString().isEmpty() ||
                        pupilLatitudeEditText.getText().toString().isEmpty() ||
                        pupilLongitudeEditText.getText().toString().isEmpty()
                ) {
                    Toast.makeText(AddPupilActivity.this, getResources().getString(R.string.please_fill_all_details), Toast.LENGTH_LONG).show();
                } else {
                    if (NetworkConnection.isConnectingToInternet(AddPupilActivity.this)) {
                        progressDialog = new ProgressDialog(AddPupilActivity.this);
                        progressDialog.setMessage(getResources().getString(R.string.adding_new_pupil_message));
                        progressDialog.setCancelable(false);
                        progressDialog.show();
                        GetDataService service = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
                        sendPost(service, pupilImageEditText.getText().toString(),
                                pupilCountryEditText.getText().toString(),
                                pupilNameEditText.getText().toString(),
                                Double.parseDouble(pupilLatitudeEditText.getText().toString()),
                                Double.parseDouble(pupilLongitudeEditText.getText().toString()));
                    } else {
                        createPupilObject();
                        databaseAdapter.insertPupil(pupil);
                        Toast.makeText(AddPupilActivity.this, getResources().getString(R.string.pupil_added_successfully_to_sqlite), Toast.LENGTH_LONG).show();
                        finish();
                    }
                }
            }
        });
    }

    private void createPupilObject() {
        pupil.setPupil_id(Long.getLong("0"));
        pupil.setCountry(pupilCountryEditText.getText().toString());
        pupil.setImage(pupilImageEditText.getText().toString());
        pupil.setName(pupilNameEditText.getText().toString());
        pupil.setLatitude(Double.parseDouble(pupilLatitudeEditText.getText().toString()));
        pupil.setLongitude(Double.parseDouble(pupilLongitudeEditText.getText().toString()));
    }

    public void sendPost(GetDataService service, String image, String country, String name, Double latitude, Double longitude) {
        pupil.setCountry(country);
        pupil.setImage(image);
        pupil.setName(name);
        pupil.setLatitude(latitude);
        pupil.setLongitude(longitude);

        service.postPupil(pupil).enqueue(new Callback<Pupil>() {
            @Override
            public void onResponse(@NonNull Call<Pupil> call, @NonNull Response<Pupil> response) {
                if (response.code() == 201) {
                    assert response.body() != null;
                    pupil.setPupil_id(response.body().getPupilid());
                    databaseAdapter.insertPupil(pupil);
                    Toast.makeText(AddPupilActivity.this, getResources().getString(R.string.pupil_added_successfully), Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    Toast.makeText(AddPupilActivity.this, getResources().getString(R.string.unable_to_post_pupil_details), Toast.LENGTH_LONG).show();
                }
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
            }

            @Override
            public void onFailure(@NonNull Call<Pupil> call, @NonNull Throwable t) {
                Toast.makeText(AddPupilActivity.this, getResources().getString(R.string.unable_to_post_pupil_details), Toast.LENGTH_LONG).show();
            }
        });
//
    }
}

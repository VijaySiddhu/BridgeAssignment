package com.example.bridgeassignment.model;

import com.google.gson.annotations.SerializedName;

public class Pupil {

    @SerializedName("pupilId")
    private Long pupilId;
    @SerializedName("name")
    private String name;
    @SerializedName("country")
    private String country;
    @SerializedName("image")
    private String image;
    @SerializedName("latitude")
    private Double latitude;
    @SerializedName("longitude")
    private Double longitude;

    public Pupil(Long pupilId, String name, String country, String image, Double latitude, Double longitude) {
        this.pupilId = pupilId;
        this.name = name;
        this.country = country;
        this.image = image;
        this.latitude = latitude;
        this.longitude = longitude;
    }
public  Pupil(){

}
    public Long getPupilid() {
        return pupilId;
    }

    public void setPupil_id(Long pupilid) {
        this.pupilId = pupilid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }
}
